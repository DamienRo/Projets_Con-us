</div>
<script src="<?= resources_uri; ?>/js/jquery-3.3.1.min.js"></script>
<script src="<?= resources_uri; ?>/js/bootstrap.min.js"></script>
<script src="<?= resources_uri; ?>/js/fontawesome-5.5.0.js"></script>


</body></html>
