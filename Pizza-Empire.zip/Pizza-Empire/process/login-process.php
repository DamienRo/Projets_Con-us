<?php
require_once('../app/app.php');

if(isset($_COOKIE['user'])) {

    $session->create('message', '<h6>Déjà connecté</h6>');
    $session->create('message-box-color', 'alert-info');

    header('location: ' . root_folder . '/index.php');

} else {
    $email = ($_POST['email']);
    $psswd = ($_POST['psswd']);

    $pdo = new PDOConnect();

    $query = $pdo->pdo_start()->prepare("SELECT * FROM users WHERE email = ? AND psswd = ?");
    $query->execute([
        $email,
        $psswd
    ]);
    $result = $query->fetch(PDO::FETCH_ASSOC);

    if ($query->rowCount() == 1) {
        $session->create('message', 'Connecté');
        $session->create('message-box-color', 'alert alert-success alert-dismissible');
        setcookie('user', $result['id'], time() + 86400*10, '/');
        $_SESSION["lname"] = $result['nom'];
        $_SESSION["fname"] = $result['prenom'];
        $_SESSION["bdate"] = $result['birth'];
        //date in mm/dd/yyyy format; or it can be in other formats as well
        $birthDate = $_SESSION["bdate"];
        //explode the date to get month, day and year
        $birthDate = explode("/", $birthDate);
        //get age from date or birthdate
        $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[1], $birthDate[2], $birthDate[0]))) > date("md")
        ? ((date("Y") - $birthDate[0]) - 1)
        : (date("Y") - $birthDate[0]));
        $_SESSION["usage"] = $age;

        $pdo->pdo_close();
        header('location: ' . root_folder . '/index.php');

    } else {
        $session->create('message', 'Erreur de connexion');
        $session->create('message-box-color', 'alert alert-danger alert-dismissible');
        $pdo->pdo_close();
        header('location: ' . root_folder . '/signin.php');
    }
}
?>
