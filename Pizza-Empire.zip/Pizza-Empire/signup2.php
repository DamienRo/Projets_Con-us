<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <style>
    @media screen and (min-width: 768px){
      .navbar-toggler{
        display: none;
      }
    }
  </style>
</head>
<body>
  <nav class="navbar navbar-expand-sm navbar-inverse bg-inverse navbar-toggleable-lg fixed-top">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" style="color: red" href="index.php">&star; MTT Resort &star;</a>&nbsp;
        <a class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="glyphicon glyphicon-menu-hamburger"></span>
        </a>
      </div>
      <ul class="nav navbar-nav collapse navbar-collapse" id="navbarNav">
        <li class="active"><a href="#">Accueil</a></li>
        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Menus <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="menus.php">Tous les menus</a></li>
            <li><a href="#">Menu 1</a></li>
            <li><a href="#">Menu 2</a></li>
            <li><a href="#">Menu 3</a></li>
            <li><a href="#">Menu 4</a></li>
          </ul>
        </li>
        <li><a href="#">Réservations</a></li>
        <li><a href="#">Contact</a></li>
        <li><a href="#">Plan</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> S'inscrire</a></li>
        <li><a href="signin.php"><span class="glyphicon glyphicon-log-in"></span> Se connecter</a></li>
      </ul>
    </div>
  </nav>
    
  <div class="container">
    <h2>Inscription</h2>
    <form class="form-horizontal" action="/action_page.php">
      <div class="form-group">
        <label class="control-label col-sm-2" for="nom">Nom:</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="nom" placeholder="Sun" name="nom">
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="prenom">Prénom:</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="prenom" placeholder="Rei" name="prenom">
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="psswd">Mot de passe:</label>
        <div class="col-sm-10">
          <input type="password" class="form-control" id="psswd" placeholder="Ralsei023" name="psswd">
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="date">Date de naissance:</label>
        <div class="col-sm-10">
          <input type="date" class="form-control" id="date" placeholder="23/12/1999" max="2002-12-31" name="date">
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="address">Adresse postale:</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="address" placeholder="Nowhere" name="address">
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="email">Email:</label>
        <div class="col-sm-10">
          <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="number">Téléphone:</label>
        <div class="col-sm-10">
          <input type="number" class="form-control" id="number" placeholder="23121999" name="number">
        </div>
      </div>
      <div class="form-group">        
        <div class="col-sm-offset-2 col-sm-10">
          <div class="checkbox">
            <label><input type="checkbox" name="remember"> Remember me</label>
          </div>
        </div>
      </div>
      <div class="form-group">        
        <div class="col-sm-offset-2 col-sm-10">
          <button type="submit" class="btn btn-default">Submit</button>
        </div>
      </div>
    </form>
  </div>
</body>
</html>
